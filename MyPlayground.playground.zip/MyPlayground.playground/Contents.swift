import UIKit

//1.- Calcular y generar una lista con los 100 primeros números primos y hacer un print de los últimos 10.

var lista:[Int] = [2,]
var contador: Int = 0

var n = 3

while lista.count<100 {
    for j in 2...n-1 {
        
        if n%j==0{
            contador += 1
            break
        }
    }
    
    if contador==0{
        //print("\(n) es primo")
        lista.append(n)
    } else{
        //print("\(n) no es primo")
    }
    
contador = 0
n+=1
}

print("Los primeros 100 números primos son \(lista)")


var lista_10: [Int] = []
for (index,values) in lista.enumerated(){
    if index > 89{
        lista_10.append(values)
    }
}

print("Los últimos 10 valores primos son \(lista_10)")




//2.- Calcular la suma de los primeros 50 números primos y hacer un print del resultado.
var suma_primos = 0

for (index, value) in lista.enumerated() {
    
    if index < 50{
        suma_primos += value
    }
    
}
print("La suma de los primos 50 números primos es \(suma_primos)")




//3.- Dada la siguiente lista, obtener todos los elementos que contengan más de dos vocales: val players: [String] = [“Vinicius”, “Messi”, “Ronaldo”, “Pedri”, “Mbappe”, “Modric”, “Militao”, “Morata”, “Valverde”, “Benzema”, “Piqué” ]

let players:[String] = ["Vinicius", "Messi", "Ronaldo", "Pedri", "Mbappe", "Modric", "Militao", "Morata", "Valverde", "Benzema", "Piqué"]

var variable=0
var vocales:[String]=[]
for i in players{
    
    if i.filter({ $0 == "a" || $0 == "A" || $0 == "á" || $0 == "Á"}).count>0{
        variable+=i.filter({ $0 == "a"}).count
    }
    if i.filter({ $0 == "e" || $0 == "E" || $0 == "é" || $0 == "É"}).count>0{
        variable+=i.filter({ $0 == "e"}).count
    }
    if i.filter({ $0 == "i" || $0 == "I" || $0 == "í" || $0 == "Í"}).count>0{
        variable+=i.filter({ $0 == "i"}).count
    }
    if i.filter({ $0 == "o" || $0 == "O" || $0 == "ó" || $0 == "Ó"}).count>0{
        variable+=i.filter({ $0 == "o"}).count
    }
    if i.filter({ $0 == "u" || $0 == "U" || $0 == "ú" || $0 == "Ú"}).count>0{
        variable+=i.filter({ $0 == "u"}).count
    }
    
    if variable > 2{
        vocales.append(i)
    }
variable = 0
}
print("Los elementos que contienen más de 2 vocales son ",vocales)



//4.- Crear un enumerado que permita indicar la posición en el campo de un jugador de fútbol, por ejemplo: Portero, Lateral Derecho, Central, Lateral Izquierdo, Mediocentro, Extremo Derecha, Extremo Izquierda, Delantero, etc

enum PosicionesFutbol{
    case Portero
    case LateralDerecho
    case Central
    case LateralIzquierdo
    case Mediocentro
    case ExtremoDerecho
    case ExtremoIzquierdo
    case Delantero
}



//5.- Crear una clase, con los atributos necesarios, para representar a los miembros que participan en una selección del mundial y un enumerado que los diferencie por tipo, por ejemplo: Jugador, Seleccionador, Médico, etc.


class Seleccion {
    
    enum TipoParticipante {
        case Jugador
        case Seleccionador
        case SegundoEntrenador
        case Medico
        case Fisioterapeuta
        case PreparadorFisico
    }
    
    var name: String
    var seleccion: String
    var tipo: TipoParticipante
    
    init(name:String,seleccion:String,tipo:TipoParticipante) {
        self.name = name
        self.seleccion = seleccion
        self.tipo = tipo
    }


}
var jugador1 = Seleccion(name: "Cristiano", seleccion: "Portugal", tipo: .Jugador)

print(jugador1.name)
print(jugador1.seleccion)
print(jugador1.tipo)

var medico1 = Seleccion(name: "Alex", seleccion: "Portugal", tipo: .Medico)

print(medico1.name)
print(medico1.seleccion)
print(medico1.tipo)


//6.- Crear las clases necesarias, con los atributos mínimos, para representar las selecciones de fútbol del Mundial de fútbol 2022, por ejemplo: Una clase que represente el Mundial, necesitaremos que contenga un listado de Selecciones, cada selección tendrá sus atributos, como nombre, país, jugadores, seleccionador, etc.

class Caracteristicas {
    
    enum mundial {
        case Qatar
        case Alemania
        case Dinamarca
        case Argentina
        case Portugal
    }
    
    var nombre: String
    var pais:String
    var jugadores: [String]
    var seleccionador:String
    var selecciones_mundial:mundial
    
    init(nombre: String, pais:String, jugadores:[String],seleccionador:String, selecciones_mundial:mundial){
        self.nombre = nombre
        self.pais = pais
        self.jugadores = jugadores
        self.seleccionador = seleccionador
        self.selecciones_mundial = selecciones_mundial
    }
}


var mundial1 = Caracteristicas(nombre: "Seleccion portugal", pais: "Portugal", jugadores: ["Cristiano Ronaldo", "Pepe","Diego Costa", "Joao Felix"], seleccionador: "Fernando Santos", selecciones_mundial: .Portugal)



//7.- Crear una clase para representar los partidos entre selecciones, deberá contener atributos como equipo local, visitante y resultado como mínimo. Generar una lista aleatoria de partidos entre la lista de selecciones anteriores y hacer un print de este estilo por partido:   Partido: España 3 - 1 Brasil

class Partidos {
    
    var equipo_local:String? = ""
    var equipo_visitante:String? = ""
    var goles_local:Int? = 0
    
    var equipos: [String] = ["Paises Bajos","Estados Unidos", "Argentina","Australia","Croacia","Japón","Brasil","Corea del Sur", "Inglaterra","Senegal", "Francia","Polonia", "Marruecos","España","Portugal","Suiza"]
    var goles: [Int] = [0,1,2,3,4,5,6,7]
    
    
    func partido() {
        guard let equipo_local = equipos.randomElement() else {return}
        guard let goles_local = goles.randomElement() else {return}
        
        guard let equipo_visitante = equipos.randomElement() else {return}
        guard let goles_visitante = goles.randomElement() else {return}
        
        if equipo_local != equipo_visitante{
            print("Partido: \(equipo_local) \(goles_local) - \(equipo_visitante) \(goles_visitante)")
        }
    }
}

var resultado = Partidos()
resultado.partido()



//8.- Generar de forma aleatoria, dentro de la clase Mundial, un listado de grupos con un máximo de 4 selecciones por grupo, se puede crear una clase nueva Grupo que contenga el nombre del grupo, listado de participantes y listado de partidos. Por ejemplo: Grupo A España, Brasil, Francia, Alemania.

class mundial2022 {
    var equipos: [String] = ["Paises Bajos","Estados Unidos", "Argentina","Australia","Croacia","Japón","Brasil","Corea del Sur", "Inglaterra","Senegal", "Francia","Polonia", "Marruecos","España","Portugal","Suiza"]
    
    var grupo1: [String] = []
    var grupo2: [String] = []
    var grupo3: [String] = []
    var grupo4: [String] = []
    var listado: [String] = []
    
    func fase_grupos(){
        
        //guard let elegido = equipos.randomElement() else {return}
        
        for _ in 1...16{
            if grupo1.count < 4 {
                grupo1.append(equipos.randomElement() ?? "")
            }
            else if grupo2.count < 4 {
                grupo2.append(equipos.randomElement() ?? "")
            }
            else if grupo3.count < 4 {
                grupo3.append(equipos.randomElement() ?? "")
            }
            else if grupo4.count < 4 {
                grupo4.append(equipos.randomElement() ?? "")
            }
        }
    }
}




var eleccion1 = mundial2022()
eleccion1.fase_grupos()
print("Grupo 1 ", eleccion1.grupo1)
print("Grupo 2 ", eleccion1.grupo2)
print("Grupo 3 ", eleccion1.grupo3)
print("Grupo 4 ", eleccion1.grupo4)


//9.- Para añadir a cada Grupo los puntos de cada selección habrá que contabilizar las victorias con 3 puntos, empates con 1 y derrotas con 0. Añadir una función en la clase Grupo que le pasemos una selección y nos devuelva sus puntos.




//10.- Generar los partidos del Mundial en cada grupo y calcular las dos primeras selecciones de cada grupo y hacer un print con los clasificados.
